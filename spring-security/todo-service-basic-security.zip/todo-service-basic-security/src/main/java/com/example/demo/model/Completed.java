package com.example.demo.model;

public enum Completed {
	YES,NO;

}