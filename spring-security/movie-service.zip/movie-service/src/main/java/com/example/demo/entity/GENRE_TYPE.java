package com.example.demo.entity;

public enum GENRE_TYPE {

ROMANTIC,

HORROR,

SCIENCE_FRICTION




}