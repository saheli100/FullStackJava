package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Person;

public interface PersonService {

	
	public List<Person> getAllPersons();
}