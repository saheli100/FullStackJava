insert into customer_table(customer_id,email,first_name,last_name) values(100,'john@gmail.com','john','doe');
insert into customer_table(customer_id,email,first_name,last_name) values(101,'marry@gmail.com','marry','kom');
