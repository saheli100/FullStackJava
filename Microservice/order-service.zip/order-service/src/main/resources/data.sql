insert into order_table(order_id,order_name,order_amount) values('odr-1','Laptop',12000);
insert into order_table(order_id,order_name,order_amount) values('odr-2','Desktop',8000);