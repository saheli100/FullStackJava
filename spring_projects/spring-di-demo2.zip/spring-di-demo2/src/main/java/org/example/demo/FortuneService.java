package org.example.demo;

public interface FortuneService {
	
	public String getDailyFortune();

}