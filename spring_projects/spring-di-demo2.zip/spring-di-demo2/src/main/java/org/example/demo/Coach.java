package org.example.demo;

public interface Coach {
	
	public String getDailyWorkout();
	
	public String getDailyFortune();

}