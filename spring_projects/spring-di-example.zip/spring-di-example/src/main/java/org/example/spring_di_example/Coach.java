package org.example.spring_di_example;

public interface Coach {
	
	public String getDailyWorkout();
	
	public String getDailyFortune();

}