package org.example.demo;

public class VolleyBallCoach implements Coach{

	@Override
	public String getDailyWorkout() {
		// TODO Auto-generated method stub
		return "practice back volley today.";
	}

}