package org.example.demo;

public class SwimmingCoach implements Coach{

	@Override
	public String getDailyWorkout() {
		// TODO Auto-generated method stub
		return "practice dive today.";
	}

}