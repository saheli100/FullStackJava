package org.example.demo;

public class CricketCoach implements Coach {

	@Override
	public String getDailyWorkout() {
		
		return "run 5k today";
	}

}
