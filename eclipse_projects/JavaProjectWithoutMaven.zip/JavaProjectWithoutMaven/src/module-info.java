/**
 * 
 */
/**
 * @author Administrator
 *
 */
module JavaProjectWithoutMaven {
	requires java.sql;
}