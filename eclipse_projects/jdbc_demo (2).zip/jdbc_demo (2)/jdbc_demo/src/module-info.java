/**
 * 
 */
/**
 * @author Administrator
 *
 */
module jdbc_demo {
	requires java.sql;
}